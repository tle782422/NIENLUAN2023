package com.lab3.authjwtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthJwtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
